The xercesImpl-2.12.0.jar file comes from the Apache Xerces project
(hhttp://xerces.apache.org/), and is licensed under the
Apache Software License, Version 2.0, which is in the
LICENSE.xerces_2_12_0.txt file.
