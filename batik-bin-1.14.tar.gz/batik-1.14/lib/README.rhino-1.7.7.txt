This distribution includes a binary distribution of Mozilla Rhino 1.7.7 release.

Rhino is licensed under both the MPL (Mozilla Public License) 2.0, which is in the LICENSE.rhino-1.7.7.txt file.
