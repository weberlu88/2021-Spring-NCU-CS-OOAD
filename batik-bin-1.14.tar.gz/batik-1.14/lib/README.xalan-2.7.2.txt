The xalan-2.7.2.jar file comes from the Apache Xalan project
(http://xml.apache.org/xalan-j/), and is licensed under the
Apache License 2.0, which can be found in the distribution root directory
in the LICENSE file.
