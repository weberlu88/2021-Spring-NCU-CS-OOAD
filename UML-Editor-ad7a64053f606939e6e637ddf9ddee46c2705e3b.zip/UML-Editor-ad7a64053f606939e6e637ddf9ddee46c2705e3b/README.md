# UML-Editor (UML編輯器)
The simple UML editor was written in JAVA. (OOAD course).

User can add new class、usecase and associaiton line object.

簡單的UML編輯器，可以新增class、usecase和association line等等的簡單功能

可以重新移動建立好的物件與線條，也能群組物件

DEMO video: https://youtu.be/2K26x_kmf9Q

class diagram of this project
![UML1](https://raw.githubusercontent.com/AwenHuang/UML-Editor/master/class%20diagram.jpg)
