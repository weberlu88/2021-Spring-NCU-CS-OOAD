package Model;

import java.awt.Point;

public class ClassObject extends BasicObject {

	public ClassObject(Point location) {
		super(location);
	}

}
