package Model;

import java.awt.Point;

public class UsecaseObject extends BasicObject {

	public UsecaseObject(Point location) {
		super(location);
	}

}
