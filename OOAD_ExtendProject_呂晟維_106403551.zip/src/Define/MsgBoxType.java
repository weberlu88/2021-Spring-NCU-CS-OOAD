package Define;

public final class MsgBoxType
{
	public final String SINGLE_LINE_INPUT_BOX = "SINGLE_LINE_INPUT_BOX";
}
