package mod;

public interface IFuncComponent
{
	public void reSize();
}
