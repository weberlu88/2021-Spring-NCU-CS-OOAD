package mod;

public interface IObjectPainter
{
	public void setText(String text);
}
