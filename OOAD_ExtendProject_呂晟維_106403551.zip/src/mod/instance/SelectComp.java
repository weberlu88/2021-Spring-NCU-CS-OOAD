package mod.instance;

import java.awt.Graphics;
import javax.swing.JPanel;

import mod.IFuncComponent;

public class SelectComp extends JPanel implements IFuncComponent
{
	public SelectComp()
	{
	}
	public void select()
	{
		
	}
	

	@Override
	public void paintComponent(Graphics g)
	{
	}

	@Override
	public void reSize()
	{
		// TODO Auto-generated method stub
	}
}
